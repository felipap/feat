
from .parse import parseLineToCommand
