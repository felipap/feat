
from .all import getFunction
# from .registerGlobal import registerGlobal

# globals = getFunction()
# for cls in all:
#   globals.append(cls)
