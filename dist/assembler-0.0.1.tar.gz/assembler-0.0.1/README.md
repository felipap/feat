
# Assembler

Given a list of feature descriptions and a corresponding set of relational
tables, automatically assembles a data set with those features.
